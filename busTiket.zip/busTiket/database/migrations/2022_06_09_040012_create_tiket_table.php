<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTiketTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tiket', function (Blueprint $table) {
            $table->id();
            $table->string('nama_lengkap');
            $table->int('nomor_identitas');
            $table->int('nomor_hp');
            $table->enum('kelas_penumpang', ['ekonomi', 'bisnis', 'eksekutif']);
            $table->date('jadwal_keberangkatan');
            $table->int('jumlah_penumpang');
            $table->int('jumlah_lansia');
            $table->int('harga');
            $table->int('total_harga');
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tiket');
    }
}
