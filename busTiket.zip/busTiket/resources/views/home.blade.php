<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Bus Tiket</title>
  </head>
  <body>
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <h1 class="display-4">Harga</h1>
    </div>

    <div class="container">
        <div class="card-deck mb-3 text-center">
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Ekonomi</h4>
                </div>
                <div class="card-body">
                    <img src="https://bengkuluekspress.rakyatbengkulu.com/wp-content/uploads/2017/05/gambar-mobil-bis.jpg" widht="200" height="100" alt="">
                    <h1 class="card-title pricing-card-title mt-5">Rp100.000</h1>
                    <button href="" type="button" class="btn btn-lg btn-block btn-outline-primary mt-2">Pesan</button>
                </div>
            </div>
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Bisnis</h4>
                </div>
                <div class="card-body">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_dz7b4Rooa8uVmVvNMCoAF8QPALtVJ2UZ1RoFJbt_FSv2YcR2yBSdFkbSo5qHZqiq2xk&usqp=CAU" width="200" height="100" alt="">
                    <h1 class="card-title pricing-card-title mt-5">Rp150.000</h1>
                    <button type="button" class="btn btn-lg btn-block btn-outline-primary mt-2">Pesan</button>
                </div>
            </div>
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Eksekutif</h4>
                </div>
                <div class="card-body">
                <img src="https://bisku.jatengsatu.com/wp-content/uploads/2020/09/02.jpg" width="200" height="100" alt="">
                    <h1 class="card-title pricing-card-title mt-5">Rp200.000</h1>
                    <button type="button" class="btn btn-lg btn-block btn-outline-primary mt-2">Pesan</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>