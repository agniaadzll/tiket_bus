<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Penumpang extends Model
{
    use HasFactory;

    protected $table = 'penumpang';
    protected $fillable = [
        'nama_lengkap', 'nomor_identitas', 'nomor_hp', 'kelas_penumpang', 'jadwal_keberangkatan', 'jumlah_penumpang', 'jumlah_lansia', 'harga', 'total_harga'
    ];
}
